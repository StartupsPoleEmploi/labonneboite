"siret","raisonsociale","enseigne","codenaf","trancheeffectif","numerorue","libellerue","codepostal","tel","email","website","flag_alternance","flag_junior","flag_senior","flag_handicap","has_multi_geolocations","codecommune","coordinates_x","coordinates_y","departement","score","email_alternance","score_alternance","social_network","phone_alternance","website_alternance","contact_mode","flag_poe_afpr","flag_pmsmp"
"01625043300220",CHAUSSURES CENDRY,GEP,"4772A","","11",RUE FABERT,"57000","","",http://www.dummywebsite.com,0,1,0,1,0,"57463",6.17528,49.1187,"57",92,"",23,,,,,0,0
"01926094200016",NICOLAS MARIUS,"","6832A","","","","57000","0123456789","",,0,1,1,0,0,"57463",0.0,0.0,"57",46,"",95,,,,,0,0
"01928065000011",COPRO STE THERESE 1,"","8110Z","","17",RUE DU XXE CORPS AMERICAIN,"57000","","",http://www.dummywebsite.com,0,0,0,0,0,"57463",6.16512,49.1036,"57",52,"",5,,,,,0,0
"01928074200016",COPRO 7 PL DU ROI GEORGES,"","8110Z","00","7",PLACE DU ROI GEORGE,"57000","","",,0,1,0,1,0,"57463",6.17141,49.1111,"57",22,"",42,,,,,0,0
"01928105400015",COPRO FRANIATTE,"","8110Z","00","50",PLACE MAZELLE,"57000","","",,0,0,0,0,0,"57463",6.18412,49.1143,"57",56,"",95,,,,,0,0
"01928108800013",COPRO RUELLE AUX ARENES,"","8110Z","00","2",IMPASSE AUX ARENES,"57000","0123456789","",,1,0,0,0,0,"57463",6.1714,49.1042,"57",13,"",50,,,,,0,0
"01928109600016",COPRO 22 R ST JEAN,"","8110Z","00","22",RUE SAINT JEAN,"57000","","",,1,0,0,0,0,"57463",6.16755,49.1025,"57",96,"",66,,,,,0,0
"01928111200011",COPRO CHARLES PETRE,S/C SOGIBLOR 401,"8110Z","00","37",RUE CHARLES PETRE,"57000","","",,0,0,0,0,0,"57463",6.16875,49.1042,"57",45,"",82,,,,,0,0
"01928124500019",COPRO IMM PALAIS DE CRISTAL,"","8110Z","","3",RUE GAMBETTA,"57000","","",http://www.dummywebsite.com,0,0,0,1,0,"57463",6.17318,49.1109,"57",36,"",10,,,,,0,0
"01928155900013",COPRO RES SAINT BERNARD,"","8110Z","","12",RUE DE LA CROIX,"57000","0123456789","",,1,0,0,0,0,"57463",6.17088,49.0979,"57",48,"",7,,,,,0,0
"01928161700019",COPRO RES SAINTE THERESE 2,"","8110Z","","7",RUE DU XXE CORPS AMERICAIN,"57000","0123456789","",,0,0,0,0,0,"57463",6.16561,49.1042,"57",29,"",4,,,,,0,0
"01934985100014",COPRO MESANGE CORCHADE,"","8110Z","","50",PLACE MAZELLE,"57000","","",,0,0,0,0,0,"57463",6.18412,49.1143,"57",3,"",98,,,,,0,0
"01935266500012",COPRO R D MARLY ET R D VOLO,"","8110Z","01","50",PLACE MAZELLE,"57000","","",,1,0,0,1,0,"57463",6.18412,49.1143,"57",30,"",81,,,,,0,0
"01935685600013",THIRIOT HENRI,"","8110Z","00","16",RUE AUX OURS,"57000","0123456789","",http://www.dummywebsite.com,0,1,1,0,0,"57463",6.17199,49.1176,"57",39,"",12,,,,,0,0
"01936671500019",COPRO ARGONE,"","8110Z","00","2",RUE DE L ARGONNE,"57000","0123456789","",,0,0,1,0,0,"57463",6.17075,49.1035,"57",8,"",18,,,,,0,0
"01936696200017", IMMEUBLE PLACE COISLIN,"","8110Z","","1",PONTDE LA SEILLE,"57000","","",,1,0,0,1,0,"57463",6.18135,49.1153,"57",23,"",56,,,,,0,0
